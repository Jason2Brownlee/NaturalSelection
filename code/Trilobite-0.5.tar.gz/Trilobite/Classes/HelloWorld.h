//
//  HelloWorld.h
//  Trilobite
//
//  Created by jasonb on 25/04/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"
#import "Environment.h"

@interface HelloWorld : Environment {

}

@end
