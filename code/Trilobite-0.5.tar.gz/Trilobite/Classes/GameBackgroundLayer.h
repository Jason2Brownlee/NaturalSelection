//
//  GameBackgroundLayer.h
//  Trilobite
//
//  Created by jasonb on 29/04/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"


@interface GameBackgroundLayer : Layer {

}

@end
