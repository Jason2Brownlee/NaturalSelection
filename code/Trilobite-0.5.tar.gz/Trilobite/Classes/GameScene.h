//
//  GameScene.h
//  Trilobite
//
//  Created by jasonb on 13/04/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "cocos2d.h"

// runing the game 
@interface GameScene : Scene {}
@end



// handling touches
@interface GameTouchLayer : Layer {}
@end



