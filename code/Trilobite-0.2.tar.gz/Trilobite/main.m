//
//  main.m
//  Trilobite
//
//  Created by jasonb on 13/04/09.
//  based on tutorial: http://monoclestudios.com/cocos2d_whitepaper.html
//

int main(int argc, char *argv[]) {
    
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil,@"TrilobiteAppDelegate");
	[pool release];
	return retVal;
}

