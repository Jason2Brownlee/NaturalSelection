//
//  B2dBlock.h
//  Trilobite
//
//  Created by jasonb on 13/04/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#ifndef B2DBLOCK_H
#define B2DBLOCK_H

#import "cocos2d.h"


#ifdef __cplusplus
	#import "Box2D.h"
#endif



@interface B2dBlock : CocosNode {

}

@end



#endif /*B2DBLOCK_H*/