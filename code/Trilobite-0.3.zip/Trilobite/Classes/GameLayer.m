//
//  GameLayer.m
//  Trilobite
//
//  Created by jasonb on 13/04/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "GameLayer.h"


@implementation GameLayer

- (id) init {
		if( ! (self=[super init]) ) {
		return nil;
	}
	
	return self;
}


-(void) dealloc{
	[super dealloc];
}

@end
