/*
 * THIS FILE IS EMPTY ON PURPOSE
 *
 * CocosNodeExtra.h has been merged into CocosNode.h
 *
 */
