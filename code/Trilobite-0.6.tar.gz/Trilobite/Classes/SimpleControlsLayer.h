//
//  SimpleControlsLayer.h
//  Trilobite
//
//  Created by jasonb on 3/05/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"


@interface SimpleControlsLayer : Layer {

}

@end
