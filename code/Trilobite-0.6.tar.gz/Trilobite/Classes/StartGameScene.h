//
//  StartGameScene.h
//  Trilobite
//
//  Created by jasonb on 2/05/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"


@interface StartGameScene : Scene {

}

@end
