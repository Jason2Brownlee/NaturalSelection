//
//  GameScene.h
//  Trilobite
//
//  Created by jasonb on 13/04/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//


#import "cocos2d.h"

@interface GameScene : Scene {

}

-(id)initWithWorld:(int)worldId;

@end

/*

// handling touches
@interface GameTouchLayer : Layer {}
@end

*/

