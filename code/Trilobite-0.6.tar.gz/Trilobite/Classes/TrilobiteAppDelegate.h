//
//  TrilobiteAppDelegate.h
//  Trilobite
//
// Initially based on tutorial:http://monoclestudios.com/cocos2d_whitepaper.html
// Stripped chipmunk so macros no longer work, instead use: http://code.google.com/p/cocos2d-iphone/issues/detail?id=290
//

#import <UIKit/UIKit.h>
#import "cocos2d.h"



@interface TrilobiteAppDelegate : NSObject <UIAlertViewDelegate, UIApplicationDelegate> {
	UIWindow *window;
}

@end

